<?php

$connect = mysqli_connect("localhost","root","","vege");

if($connect)
{

	//echo("Connect successfully");
}
else
{

	echo("Connect Unsuccessfully");

}

?>