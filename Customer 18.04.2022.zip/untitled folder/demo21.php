<script>
function checkEmail()
{
    var email = document.getElementById("password");
    var email_check = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(!email.value.match(email_check))
    {
        document.getElementById("showmsg").innerHTML = "HELLO";
        return false;
    }
    return true;


}
</script>
<!DOCTYPE html>
<html>
<body>
<form autocomplete="off" onsubmit="return checkEmail()">
  
<p>Email</p>
<input type="email" id="password" autocomplete="off" name="email"  required>
<span id="showmsg" class="text-danger"></span>
<button type="submit">Submit</button>

</form>
</body>
</html>

