<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function(){
    $("#card").click(function(){
        $(".card-box").show();
        $(".cash-box").hide();
        $("#ccard").attr("required",true);
        $("#ccvv").attr("required",true);
        $("#cmonth").attr("required",true);
        $("#cyear").attr("required",true);
        $("#tnc").attr("required",true);

    });

    $("#cash").click(function(){
        $(".card-box").hide();
        $(".cash-box").show();
        $("#ccard").removeAttr("required");
        $("#ccvv").removeAttr("required");
        $("#cmonth").removeAttr("required");
        $("#cyear").removeAttr("required");
        $("#tnc").attr("required",true);
    });
});
</script>
<script>
    function getOption()
    {
                    $(document).ready(function() {
                // On refresh check if there are values selected
                if (localStorage.selectVal) {
                        // Select the value stored
                    $('select').val( localStorage.selectVal );
                }
            });

            // On change store the value
            $('select').on('change', function(){
                var currentVal = $(this).val();
                localStorage.setItem('selectVal', currentVal );
            });
        }
</script>
<script>
    function validate()
    {
    var name_check=0;
    var name= document.billing.fname.value;
    var address = document.billing.add.value;
    var zip = document.billing.zip.value;
    var phone = document.billing.phone.value;
    var state =document.billing.state.value;
    var email =document.billing.email.value;
    var c_num = document.billing.card_num.value;
    var c_cvv = document.billing.card_cvv.value;
    
        if(name=="")
        {
            document.getElementById("errorname").innerHTML="Please Enter your name.";
        }
        else
        {
            document.getElementById("errorname").innerHTML="";
        }
    
        if(address=="")
        {
            document.getElementById("erroradd").innerHTML="Please provided the address.";
        }
        else
        {
            document.getElementById("erroradd").innerHTML="";
        }
    
        if(zip==""||isNaN(zip))
        {
            document.getElementById("errorzip").innerHTML="Please provided valid the Postcode";
        }
        else
        {
            document.getElementById("errorzip").innerHTML="";
        }
        if(phone==""||isNaN(phone))
        {
            document.getElementById("errorphone").innerHTML="Please provided the valid PhoneNumber";
        }
        else
        {
            document.getElementById("errorphone").innerHTML="";
        }
        var pattern =/^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
        if(email=="" || !pattern.test(email))
        {
            document.getElementById("erroremail").innerHTML="Please provided the valid Email";
            return false;
        }
        else
        {
            document.getElementById("erroremail").innerHTML="";
        }
            
            if(c_num==""||isNaN(c_num)||c_num.length<16||c_num.length>16)
            {
                document.getElementById("errorcard").innerHTML="Invalid Card Number";
                
            }
            else 
            {
                document.getElementById("errorcard").innerHTML="";
            }
            
            if(c_cvv==""||isNaN(c_cvv)||c_cvv.length<3||c_cvv.length>3)
            {
                document.getElementById("errorcvv").innerHTML="Invalid CVV";
            }
            else
            {
                document.getElementById("errorcvv").innerHTML="";
            }
            if(document.billing.card_month.selectedIndex=="")
            {
                document.getElementById("errormonth").innerHTML="Please select the month";
            }
            else
            {
                document.getElementById("errormonth").innerHTML="";
            }
            if(document.billing.card_years.selectedIndex=="")
            {
                document.getElementById("erroryears").innerHTML="Please select the years";
            }
            else
            {
                document.getElementById("erroryears").innerHTML="";
            }
            
            
        }
</script>

<script>
$('.tnc').on('input', function() {
  var input = $( this );
  var is_checked = $("input[name=tnc]:checked").prop("checked");
  if (is_checked){ 
    $('.error').removeClass("invalid").addClass("valid");
  } else {
    $('.error').removeClass("valid").addClass("invalid");
  }
});
</script>

<!DOCTYPE html>
<html>
<head>
<title>Checkout Page</title>
</head>
<form  id="billing" name="billing" method="POST" autocomplete="off">
    <input type="radio" name="pay"  id="card" value="card">Card Payment
    <input type="radio" name="pay"  id="cash" value="cash">Cash Payment
    <br>
    <h3>Delivery Details</h3>
    <label>Name: </label>
    <br><input type="text" name="fname" pattern="[a-zA-Z]{1,}" title="Only insert the alphabetic letter" value="<?php if(isset($_POST['fname'])){echo $_POST['fname'];}?>" required>
    <span id="errorname" style="color:red"></span>
    <br>
    <label>State</label>
    <select name="state" onchange="getOption()" value="<?php if(isset($_POST['state'])){echo $_POST['state'];}?>" required>
    <option value="Kuala Lumpur">Kuala Lumpur</option>
    <option value="Selangor">Selangor</option>
    <option value="Melaka">Melaka</option>    
    <option value="Negeri Sembilan">Negeri Sembilan</option>
    <option value="Pahang">Pahang</option>
    <option value="Kelantan">Kelantan</option>
    <option value="Terrenganu">Terrenganu</option>
    <option value="Penang">Penang</option>
    <option value="Perlis">Perlis</option>
    <option value="Kedah">Kedah</option>
    <option value="Perak">Perak</option>
    <option value="Johor">Johor</option>
    <option value="Sabah">Sabah</option>
    <option value="Sarawak">Sarawak</option>
    </select>
    <span id="errorstate" style="color:red"></span>
    <br>
    <label>Address(Please State Clearly)</label>
    <input type="text" name="add" value="<?php if(isset($_POST['add'])){echo $_POST['add'];}?>" required>
    <span id="erroradd" style="color:red"></span>
    <br>
    <label>PostCodeZip</label>
    <input type="text" name="zip" pattern="[0-9]{5}" title="Error Length" minlength="5"  value="<?php if(isset($_POST['zip'])){echo $_POST['zip'];}?>" required>
    <span id="errorzip" style="color:red"></span>
    <br>
    <label>Phone Number</label>
    <input type="text" name="phone" pattern="[0-9]{3}[0-9]{7,8}" value="<?php if(isset($_POST['phone'])){echo $_POST['phone'];}?>" required>
    <span id="errorphone" style="color:red"></span>
    <br>
    <label>Email Address</label>
    <input type="email" name="email" value="<?php if(isset($_POST['email'])){echo $_POST['email'];}?>" required>
    <span id="erroremail" style="color:red"></span>
    <br>
    <div class="card-box" id="card-box" style="display:none">
    <label>Card Number</label>
    <input type="text" id="ccard" name="card_num" minlength="16" maxlength="16" pattern="[1-99]{16}"  title="Please Key in the correct 16 digit">
    <span id="errorcard" style="color:red"></span>
    <br>
    <label>Cvv</label>
    <input type="text" name="card_cvv" id="ccvv" pattern="[0-99]{3}" minlength="3" maxlength="3" title="Please Key in the correct 3 digit">
    <span id="errorcvv" style="color:red"></span>
    <br>
    <label>Expiry Date</label>
    <select class="cc"id="cmonth" name="card_month" title="MANDATORY to choose a month">
        <option value="">Select Month</option>
								<option value="01">January</option>
								<option value="02">February</option>
								<option value="03">March</option>
								<option value="04">April</option>
								<option value="05">May</option>
								<option value="06">June</option>
								<option value="07">July</option>
								<option value="08">August</option>
								<option value="09">September</option>
								<option value="10">October</option>
								<option value="11">November</option>
								<option value="12">December</option>
    </select>
    <span id="errormonth" style="color:red"></span>
    <br>
    <label>Years</label>
    <select class="cc"id="cyear" name="card_years" title="MANDATORY to choose a year">
        <option value="">Select Year</option>
        <option value="2012">2012</option>
        <option value="2013">2013</option>
        <option value="2014">2014</option>
        <option value="2015">2015</option>
        <option value="2016">2016</option>
        <option value="2017">2017</option>
        <option value="2018">2018</option>
        <option value="2019">2019</option>
        <option value="2020">2020</option>
        <option value="2021">2021</option>
        <option value="2022">2022</option>
        <option value="2023">2023</option>
        <option value="2024">2024</option>
        <option value="2025">2025</option>
        <option value="2026">2026</option>                          
        <option value="2027">2027</option>
        <option value="2028">2028</option>
        <option value="2029">2029</option>
        <option value="2030">2030</option>
        <option value="2031">2031</option>
        <option value="2032">2032</option>
        <option value="2033">2033</option>
        <option value="2034">2034</option>
        <option value="2035">2035</option>
        <option value="2036">2036</option>  
    </select>
    <span id="erroryears" style="color:red"></span>
    </div>
    <input type="radio" id="tnc" name="tnc"  title="You haven't agree the Terms and Condition" class="mr-2 tnc" required>I have read and accept the terms and conditions
    
    <div class="card-box" style="display:none">
       <button type="submit" value="Place to Order"  onClick="validate()" name="cardbutton">Place to Order</button>
   </div>
    <div class="cash-box" style="display:none">
        <button type="submit" value="Place to Order" onClick="validate()"   name="cashbutton">Place to Order</button>
    </div>
    

</form>
</html>
