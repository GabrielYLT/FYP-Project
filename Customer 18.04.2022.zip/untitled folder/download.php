<?php
include("dataconnection.php");
error_reporting(0);
require('fpdf184/fpdf.php');

if(isset($_GET['pid']))
{
    $id = $_GET['pid'];
    $result = mysqli_query($connect,"SELECT * FROM ((customer_order INNER JOIN payment ON customer_order.payment_id = payment.payment_id)
    INNER JOIN product ON customer_order.product_id = product.Product_ID)
    WHERE customer_order.payment_id = $id");

    $result2 = mysqli_query($connect,"SELECT DISTINCT product.Product_Image,product.Product_ID,product.Product_Name,product.Product_Price,customer_order.quantity FROM product 
    INNER JOIN customer_order ON product.Product_ID = customer_order.product_id WHERE customer_order.payment_id=$id");       

    if(mysqli_num_rows($result)>0)
      {
         $row = mysqli_fetch_assoc($result);
      
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->setFont('Arial','B',12);
            
            $pdf->Cell(140,5,"JJG FRUITS & VEGE");
            $pdf->Cell(20,5,"Email: jjgfruit@gmail.com");

            $pdf->Ln(20);
            $pdf->Cell(10,5,'',0,0);
            $pdf->Cell(20,5,'Order ID: ',0,0);
            $pdf->Cell(80,5,$row['Order_ID'],0,0);
            $pdf->Cell(25,5,'Order Date',0,0);
            $pdf->Cell(52,5,$row['order_date'],1,1,'C');

            $pdf->Line(10,50,200,50);

            $pdf->Ln(20);
            $pdf->Cell(10,5,"Delivery Details",0,0);
            $pdf->Ln(7);
            
            $pdf->Cell(50,5,'Receiver Name           : ',0,0);
            $pdf->Cell(58,5,$row['payment_name'],0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Delivery Address        :',0,0);
            $pdf->Cell(52,5,$row['payment_address'],0,1);


            $pdf->Ln(2);
            $pdf->Cell(50,5,'Delivery State              : ',0,0);
            $pdf->Cell(55,5,$row['payment_state'],0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Delivery Postcode       : ',0,0);
            $pdf->Cell(52,5,$row['payment_postcode'],0,1);

            $pdf->Ln(2);
            $pdf->Cell(50,5,'Contact Number           : ',0,0);
            $pdf->Cell(55,5,$row['payment_phone'],0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Contact Email               : ',0,0);
            $pdf->Cell(52,5,$row['payment_email'],0,1);

            $pdf->Line(10,110,200,110);

            $pdf->Ln(15);
            $pdf->Cell(10,5,"Payment Details",0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Payment Method         : ',0,0);
            $pdf->Cell(55,5,$row['payment_method'],0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Payment Price             :',0,0);
            $pdf->Cell(52,5,"RM ".number_format($row['payment_price'],2,'.',''),0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Payment Status           :',0,0);
            $pdf->Cell(52,5,$row['Payment_Status'],0,1);
            $pdf->Ln(2);
            $pdf->Cell(50,5,'Order Status                :',0,0);
            $pdf->Cell(52,5,$row['Order_Status'],0,1);
            $pdf->Line(10,900,200,900);
            $pdf->Ln(15);
            
            
            $pdf->Cell(10,5,"Product Purchased Details",0,1);
            while($row1 = mysqli_fetch_assoc($result2))
            {
                $pdf->Ln(2);
                $pdf->Cell(65,5,"Product Name                            :",0,0);
                $pdf->Cell(55,5,$row1['Product_Name'],0,1);
                $pdf->Cell(65,5,"Product Quantity Purchased    :  ",0,0);
                $pdf->Cell(60,5,$row1['quantity'],0,1);
            }
            $pdf->Output();
      }
}
    ?>
